#!/system/bin/sh
BACKUP=/data/local/tmp/obsidian_turbo_backup
mkdir -p $BACKUP

# Guardar estado actual
settings get global window_animation_scale > $BACKUP/win_anim.txt
settings get global transition_animation_scale > $BACKUP/trans_anim.txt
settings get global animator_duration_scale > $BACKUP/anim_dur.txt
settings get global low_power > $BACKUP/low_power.txt

# 1) Reducir animaciones a 0.5x (sensación de rapidez sin tocar hardware)
settings put global window_animation_scale 0.5
settings put global transition_animation_scale 0.5
settings put global animator_duration_scale 0.5

# 2) Forzar rendimiento máximo permanente (deshabilitar ahorro)
settings put global low_power 0
cmd power set-fixed-performance-mode-enabled true 2>/dev/null

# 3) Deshabilitar Doze agresivo para apps en primer plano
cmd deviceidle whitelist +com.obsidian.manager 2>/dev/null

# 4) Liberar RAM de fondo
am kill-all 2>/dev/null

echo "== Turbo G99 aplicado =="
echo "Animaciones: 0.5x"
echo "Fixed performance mode: ON"
echo "Doze whitelist: OK"
echo ""
echo "Backup guardado en $BACKUP"ales pueden variar.
# Se recomienda usar "Root Box" o "Scene" para monitorear las temperaturas.
# Por seguridad, solo establecemos el governor en "performance" y no forzamos frecuencias altas manualmente.

# Forzar el governor de la CPU a "performance" (esto es más seguro que fijar la frecuencia)
for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    echo "performance" > "$cpu"
done

# Forzar el governor de la GPU a "performance" (si existe)
echo "performance" > /sys/class/devfreq/mtk-mali/governor 2>/dev/null

# Nota: En lugar de escribir un valor de frecuencia directamente, el governor "performance"
# permite que el hardware vaya a su máxima frecuencia soportada de forma nativa y segura.
# Si deseas forzar una frecuencia manual (MÁS RIESGOSO), descomenta las siguientes líneas
# y AJUSTA los valores a los que soporte tu dispositivo.
# echo "2200000" > /sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq
# echo "2000000" > /sys/devices/system/cpu/cpu4/cpufreq/scaling_max_freq
# echo "1003000000" > /sys/class/devfreq/mtk-mali/max_freq

echo "Optimización aplicada. Los valores se restaurarán al reiniciar."
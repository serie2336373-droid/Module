#!/system/bin/sh
BACKUP=/data/local/tmp/obsidian_turbo_backup
sleep 15

if [ -f $BACKUP/win_anim.txt ]; then
    settings put global window_animation_scale $(cat $BACKUP/win_anim.txt)
    settings put global transition_animation_scale $(cat $BACKUP/trans_anim.txt)
    settings put global animator_duration_scale $(cat $BACKUP/anim_dur.txt)
    settings put global low_power $(cat $BACKUP/low_power.txt)
    cmd power set-fixed-performance-mode-enabled false 2>/dev/null
    rm -rf $BACKUP
    echo "Valores restaurados"
fivices/system/cpu/cpu4/cpufreq/scaling_max_freq
    fi
    
    # Restaurar governor de CPU a "schedutil" (o el que use tu dispositivo por defecto)
    for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
        echo "schedutil" > "$cpu"
    done
    
    # Restaurar GPU
    if [ "$GPU_MAX_ORIG" != "0" ]; then
        echo "$GPU_MAX_ORIG" > /sys/class/devfreq/mtk-mali/max_freq
    fi
    echo "schedutil" > /sys/class/devfreq/mtk-mali/governor 2>/dev/null
    
    echo "Restauración completada. Eliminando archivo de backup."
    rm "$BACKUP_FILE"
else
    echo "No se encontró backup. No hay nada que restaurar."
fi